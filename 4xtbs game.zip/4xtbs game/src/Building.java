
public class Building {

}
